package com.touristagency.TouristAgency.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.touristagency.TouristAgency.dto.PrevozDTO;
import com.touristagency.TouristAgency.model.Prevoz;
import com.touristagency.TouristAgency.repository.PrevozRepository;

@Service
public class PrevozService {

	@Autowired
	PrevozRepository prevozRepository;
	
	public PrevozDTO createPrevoz(PrevozDTO prevozDTO) {
		Prevoz prevoz = new Prevoz(prevozDTO);
		prevozRepository.save(prevoz);
		return new PrevozDTO(prevoz);
	}

	public List<PrevozDTO> getAllPrevoz(){
		List<Prevoz> prevozi = prevozRepository.findAll(); 
		List<PrevozDTO> prevoziDTO = new ArrayList<>();
		for(Prevoz prevoz : prevozi) {
			prevoziDTO.add(new PrevozDTO(prevoz));
		}
		return prevoziDTO;
	}

	public PrevozDTO getPrevoz(Long id) {
		return new PrevozDTO(prevozRepository.getReferenceById(id));
	}

	public PrevozDTO updatePrevoz(PrevozDTO prevozDTO) {
		Prevoz prevoz = prevozRepository.getReferenceById(prevozDTO.getId());
		prevoz.setNaziv(prevozDTO.getNaziv());
		return new PrevozDTO(prevozRepository.save(prevoz));
	}

	public void deletePrevoz(Long id) {
		prevozRepository.deleteById(id);
	}
}
