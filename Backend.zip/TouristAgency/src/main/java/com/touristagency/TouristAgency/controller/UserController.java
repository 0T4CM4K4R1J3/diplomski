package com.touristagency.TouristAgency.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.touristagency.TouristAgency.dto.LoginDTO;
import com.touristagency.TouristAgency.dto.UserDTO;
import com.touristagency.TouristAgency.service.UserService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping(value="users")
public class UserController {
	
	@Autowired
	UserService userService;
	
	@PostMapping	
	public ResponseEntity<UserDTO> createUser(@RequestBody UserDTO userDTO) {	
		UserDTO user = userService.createUser(userDTO);		
		return new ResponseEntity<UserDTO>(user, HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<UserDTO>> getAllKorisnici(){
		List<UserDTO> korisnici = userService.getAllKorisnici();
		return new ResponseEntity<List<UserDTO>>(korisnici, HttpStatus.OK);
	}
	
	@GetMapping(value="/{id}")
	public ResponseEntity<UserDTO> getUser(@PathVariable Long id){
		UserDTO user = userService.getKorisnik(id);
		return new ResponseEntity<UserDTO>(user, HttpStatus.OK);
	}
	
	@PutMapping	
	public ResponseEntity<UserDTO> updateUser(@RequestBody UserDTO userDTO) {	
		UserDTO user = userService.updateKorisnik(userDTO);		
		return new ResponseEntity<UserDTO>(user, HttpStatus.OK);
	}
	
	@DeleteMapping(value="/{id}")
	public ResponseEntity<?> deleteUser(@PathVariable Long id){
		userService.deleteUser(id);
		return new ResponseEntity<>("Korisnik uspesno obrisan", HttpStatus.OK);
	}
	
	@PostMapping(value="/login")	
	public ResponseEntity<UserDTO> login(@RequestBody LoginDTO loginDTO) {	
		UserDTO user = userService.login(loginDTO);		
		return new ResponseEntity<UserDTO>(user, HttpStatus.CREATED);
	}
}

