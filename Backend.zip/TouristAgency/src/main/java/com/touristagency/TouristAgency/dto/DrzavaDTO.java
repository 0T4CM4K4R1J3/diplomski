package com.touristagency.TouristAgency.dto;

import com.touristagency.TouristAgency.model.Drzava;

public class DrzavaDTO {

	private Long id;
	private String naziv;
	
	public DrzavaDTO() {}
	
	public DrzavaDTO(Drzava drzava) {
		this.id = drzava.getId();
		this.naziv = drzava.getNaziv();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}
	
	
}
