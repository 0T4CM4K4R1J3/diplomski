package com.touristagency.TouristAgency.dto;

import com.touristagency.TouristAgency.model.Aranzman;

public class DetaljanAranzmanDTO {
	private Long id;
	private int brojKreveta;
	private String adresa;
	private String slika;	
	private int zvezdica;	
	private int plaza;	
	private boolean internet;	
	private String opis;	
	private int cenaZaOdrasluOsobu;
	private int cenaZaDete;
	
	public DetaljanAranzmanDTO() {}
	
	public DetaljanAranzmanDTO(Aranzman a) {
		this.id = a.getId();
		this.brojKreveta = a.getBrojKreveta();
		this.adresa = a.getSmestajOpis().getAdresa();
		this.slika = a.getSmestajOpis().getSlika();
		this.zvezdica = a.getSmestajOpis().getZvezdica();
		this.plaza = a.getSmestajOpis().getPlaza();
		this.internet = a.getSmestajOpis().isInternet();
		this.opis = a.getSmestajOpis().getOpis();
		this.cenaZaOdrasluOsobu = a.getCenaZaOdrasluOsobu();
		this.cenaZaDete = a.getCenaZaDete();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getBrojKreveta() {
		return brojKreveta;
	}

	public void setBrojKreveta(int brojKreveta) {
		this.brojKreveta = brojKreveta;
	}

	public String getAdresa() {
		return adresa;
	}

	public void setAdresa(String adresa) {
		this.adresa = adresa;
	}

	public String getSlika() {
		return slika;
	}

	public void setSlika(String slika) {
		this.slika = slika;
	}

	public int getZvezdica() {
		return zvezdica;
	}

	public void setZvezdica(int zvezdica) {
		this.zvezdica = zvezdica;
	}

	public int getPlaza() {
		return plaza;
	}

	public void setPlaza(int plaza) {
		this.plaza = plaza;
	}

	public boolean isInternet() {
		return internet;
	}

	public void setInternet(boolean internet) {
		this.internet = internet;
	}

	public String getOpis() {
		return opis;
	}

	public void setOpis(String opis) {
		this.opis = opis;
	}

	public int getCenaZaOdrasluOsobu() {
		return cenaZaOdrasluOsobu;
	}

	public void setCenaZaOdrasluOsobu(int cenaZaOdrasluOsobu) {
		this.cenaZaOdrasluOsobu = cenaZaOdrasluOsobu;
	}

	public int getCenaZaDete() {
		return cenaZaDete;
	}

	public void setCenaZaDete(int cenaZaDete) {
		this.cenaZaDete = cenaZaDete;
	}


}
