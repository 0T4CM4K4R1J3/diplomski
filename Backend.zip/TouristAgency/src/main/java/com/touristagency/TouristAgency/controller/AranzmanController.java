package com.touristagency.TouristAgency.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.touristagency.TouristAgency.dto.AranzmanDTO;
import com.touristagency.TouristAgency.dto.DetaljanAranzmanDTO;
import com.touristagency.TouristAgency.service.AranzmanService;

@RestController
@RequestMapping(value="aranzman")
public class AranzmanController {

	@Autowired
	AranzmanService aranzmanService;
	
	@PostMapping	
	public ResponseEntity<AranzmanDTO> createAranzman(@RequestBody AranzmanDTO aranzmanDTO) {	
		AranzmanDTO aranzman = aranzmanService.createAranzman(aranzmanDTO);		
		return new ResponseEntity<AranzmanDTO>(aranzman, HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<DetaljanAranzmanDTO>> getAllAranzmani(){
		List<DetaljanAranzmanDTO> aranzman = aranzmanService.getAllAranzman();
		return new ResponseEntity<List<DetaljanAranzmanDTO>>(aranzman, HttpStatus.OK);
	}
	
	@GetMapping(value="/{id}")
	public ResponseEntity<AranzmanDTO> getAranzman(@PathVariable Long id){
		AranzmanDTO aranzman = aranzmanService.getAranzman(id);
		return new ResponseEntity<AranzmanDTO>(aranzman, HttpStatus.OK);
	}
	
	@PutMapping	
	public ResponseEntity<AranzmanDTO> updateAranzman(@RequestBody AranzmanDTO aranzmanDTO) {	
		AranzmanDTO aranzman = aranzmanService.updateAranzman(aranzmanDTO);		
		return new ResponseEntity<AranzmanDTO>(aranzman, HttpStatus.OK);
	}
	
	@DeleteMapping(value="/{id}")
	public ResponseEntity<?> deleteAranzman(@PathVariable Long id){
		aranzmanService.deleteAranzman(id);
		return new ResponseEntity<>("Aranzman uspesno obrisan", HttpStatus.OK);
	}
}
