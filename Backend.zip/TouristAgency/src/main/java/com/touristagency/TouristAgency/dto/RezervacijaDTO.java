package com.touristagency.TouristAgency.dto;

import com.touristagency.TouristAgency.model.Rezervacija;

public class RezervacijaDTO {

	private Long id;
	private int brojOdraslih;
	private int brojDece;
	private int cena;
	private Long userId;
	private Long prevozId;
	private Long aranzmanId;
	
	public RezervacijaDTO() {}

	public RezervacijaDTO(Rezervacija rezervacija) {
		this.id = rezervacija.getId();
		this.brojDece = rezervacija.getBrojDece();
		this.brojOdraslih = rezervacija.getBrojOdraslih();
		this.cena = rezervacija.getCena();
		this.userId = rezervacija.getUser().getId();
		this.prevozId = rezervacija.getPrevoz().getId();
		this.aranzmanId = rezervacija.getAranzman().getId();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getBrojOdraslih() {
		return brojOdraslih;
	}

	public void setBrojOdraslih(int brojOdraslih) {
		this.brojOdraslih = brojOdraslih;
	}

	public int getBrojDece() {
		return brojDece;
	}

	public void setBrojDece(int brojDece) {
		this.brojDece = brojDece;
	}

	public int getCena() {
		return cena;
	}

	public void setCena(int cena) {
		this.cena = cena;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getPrevozId() {
		return prevozId;
	}

	public void setPrevozId(Long prevozId) {
		this.prevozId = prevozId;
	}

	public Long getAranzmanId() {
		return aranzmanId;
	}

	public void setAranzmanId(Long aranzmanId) {
		this.aranzmanId = aranzmanId;
	}
	
	
}
