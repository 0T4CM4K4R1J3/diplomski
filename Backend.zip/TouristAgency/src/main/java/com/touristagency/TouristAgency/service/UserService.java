package com.touristagency.TouristAgency.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.touristagency.TouristAgency.dto.LoginDTO;
import com.touristagency.TouristAgency.dto.UserDTO;
import com.touristagency.TouristAgency.model.User;
import com.touristagency.TouristAgency.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	UserRepository userRepository;

	public UserDTO createUser(UserDTO userDTO) {
		User user = new User(userDTO);
		userRepository.save(user);
		return new UserDTO(user);
	}
	
	public List<UserDTO> getAllKorisnici(){
		List<User> korisnici = userRepository.findAll(); 
		List<UserDTO> korisniciDTO = new ArrayList<>();
		for(User korisnik : korisnici) {
			korisniciDTO.add(new UserDTO(korisnik));
		}
		return korisniciDTO;
	}

	public UserDTO getKorisnik(Long id) {
		return new UserDTO(userRepository.getReferenceById(id));
	}

	public UserDTO updateKorisnik(UserDTO userDTO) {
		User user = userRepository.getReferenceById(userDTO.getId());
		user.setEmail(userDTO.getEmail());
		user.setName(userDTO.getName());
		user.setPassword(userDTO.getPassword());
		user.setRole(userDTO.getRole());
		return new UserDTO(userRepository.save(user));
	}

	public void deleteUser(Long id) {
		userRepository.deleteById(id);
	}

	public UserDTO login(LoginDTO loginDTO) {
		List<UserDTO> allUsers = this.getAllKorisnici();
		for(UserDTO user : allUsers) {
			if(user.getEmail().equals(loginDTO.getEmail()) && user.getPassword().equals(loginDTO.getPassword())){
				return user;
			}
			
		}
		return null;
	}
}
