package com.touristagency.TouristAgency.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.touristagency.TouristAgency.dto.DestinacijaDTO;
import com.touristagency.TouristAgency.model.Destinacija;
import com.touristagency.TouristAgency.repository.DestinacijaRepository;
import com.touristagency.TouristAgency.repository.GradRepository;

@Service
public class DestinacijaService {

	@Autowired
	DestinacijaRepository destinacijaRepository;
	@Autowired
	GradService gradService;
	@Autowired
	GradRepository gradRepository;
	
	public DestinacijaDTO createDestinacija(DestinacijaDTO destinacijaDTO) {
		Destinacija destinacija = new Destinacija(destinacijaDTO);
		destinacija.setGrad(gradRepository.getReferenceById(destinacijaDTO.getGradId()));
		destinacijaRepository.save(destinacija);
		return new DestinacijaDTO(destinacija);
	}
	
	public List<DestinacijaDTO> getAllDestinacija(){
		List<Destinacija> destinacije = destinacijaRepository.findAll(); 
		List<DestinacijaDTO> destinacijeDTO = new ArrayList<>();
		for(Destinacija destinacija : destinacije) {
			destinacijeDTO.add(new DestinacijaDTO(destinacija));
		}
		return destinacijeDTO;
	}

	public DestinacijaDTO getDestinacija(Long id) {
		return new DestinacijaDTO(destinacijaRepository.getReferenceById(id));
	}

	public DestinacijaDTO updateDestinacija(DestinacijaDTO destinacijaDTO) {
		Destinacija destinacija = this.destinacijaRepository.getReferenceById(destinacijaDTO.getId());
		destinacija.setNaziv(destinacijaDTO.getNaziv());
		destinacija.setGrad(gradRepository.getReferenceById(destinacijaDTO.getGradId()));
		return new DestinacijaDTO(destinacijaRepository.save(destinacija));
	}

	public void deleteDestinacija(Long id) {
		destinacijaRepository.deleteById(id);
	}
}
