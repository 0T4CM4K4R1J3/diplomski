package com.touristagency.TouristAgency;

import org.springframework.web.servlet.config.annotation.CorsRegistry;;

public class CorsConfiguration {
	  public void addCorsMappings(CorsRegistry registry) {
	        registry.addMapping("/**").allowedMethods("PUT", "DELETE", "POST", "GET").allowedOrigins("http://localhost:3000");
	        
	    }
}
