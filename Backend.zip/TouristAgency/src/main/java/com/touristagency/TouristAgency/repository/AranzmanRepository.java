package com.touristagency.TouristAgency.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.touristagency.TouristAgency.model.Aranzman;

@Repository
public interface AranzmanRepository extends JpaRepository<Aranzman,Long> {

}
