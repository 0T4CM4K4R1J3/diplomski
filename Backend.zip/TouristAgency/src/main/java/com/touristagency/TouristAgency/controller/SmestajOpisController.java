package com.touristagency.TouristAgency.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.touristagency.TouristAgency.dto.SmestajOpisDTO;
import com.touristagency.TouristAgency.service.SmestajOpisService;

@RestController
@RequestMapping(value="smestajopis")
public class SmestajOpisController {

	@Autowired
	SmestajOpisService smestajOpisService;
	
	@PostMapping	
	public ResponseEntity<SmestajOpisDTO> createSmestajOpis(@RequestBody SmestajOpisDTO smestajOpisDTO) {	
		SmestajOpisDTO smestajOpis = smestajOpisService.createSmestajOpis(smestajOpisDTO);		
		return new ResponseEntity<SmestajOpisDTO>(smestajOpis, HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<SmestajOpisDTO>> getAllSmestajOpis(){
		List<SmestajOpisDTO> smestajOpis = smestajOpisService.getAllSmestajOpis();
		return new ResponseEntity<List<SmestajOpisDTO>>(smestajOpis, HttpStatus.OK);
	}
	
	@GetMapping(value="/{id}")
	public ResponseEntity<SmestajOpisDTO> getSmestajOpis(@PathVariable Long id){
		SmestajOpisDTO smestajOpis = smestajOpisService.getSmestajOpis(id);
		return new ResponseEntity<SmestajOpisDTO>(smestajOpis, HttpStatus.OK);
	}
	
	@PutMapping	
	public ResponseEntity<SmestajOpisDTO> updateSmestajOpis(@RequestBody SmestajOpisDTO smestajOpisDTO) {	
		SmestajOpisDTO smestajOpis = smestajOpisService.updateSmestajOpis(smestajOpisDTO);		
		return new ResponseEntity<SmestajOpisDTO>(smestajOpis, HttpStatus.OK);
	}
	
	@DeleteMapping(value="/{id}")
	public ResponseEntity<?> deleteSmestajOpis(@PathVariable Long id){
		smestajOpisService.deleteSmestajOpis(id);
		return new ResponseEntity<>("Smestaj opis uspesno obrisan", HttpStatus.OK);
	}
	
}
