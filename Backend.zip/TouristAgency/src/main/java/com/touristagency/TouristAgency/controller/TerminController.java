package com.touristagency.TouristAgency.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.touristagency.TouristAgency.dto.TerminDTO;
import com.touristagency.TouristAgency.service.TerminiService;

@RestController
@RequestMapping(value="termin")
public class TerminController {

	@Autowired
	TerminiService terminService;
	
	@PostMapping	
	public ResponseEntity<TerminDTO> createTermin(@RequestBody TerminDTO terminDTO) {	
		TerminDTO termin = terminService.createTermin(terminDTO);		
		return new ResponseEntity<TerminDTO>(termin, HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<TerminDTO>> getAllTermin(){
		List<TerminDTO> termini = terminService.getAllTermin();
		return new ResponseEntity<List<TerminDTO>>(termini, HttpStatus.OK);
	}
	
	@GetMapping(value="/{id}")
	public ResponseEntity<TerminDTO> getTermin(@PathVariable Long id){
		TerminDTO termin = terminService.getTermin(id);
		return new ResponseEntity<TerminDTO>(termin, HttpStatus.OK);
	}
	
	@PutMapping	
	public ResponseEntity<TerminDTO> updateTermin(@RequestBody TerminDTO terminDTO) {	
		TerminDTO termin = terminService.updateTermin(terminDTO);		
		return new ResponseEntity<TerminDTO>(termin, HttpStatus.OK);
	}
	
	@DeleteMapping(value="/{id}")
	public ResponseEntity<?> deleteTermin(@PathVariable Long id){
		terminService.deleteTermin(id);
		return new ResponseEntity<>("Termin uspesno obrisan", HttpStatus.OK);
	}
}
