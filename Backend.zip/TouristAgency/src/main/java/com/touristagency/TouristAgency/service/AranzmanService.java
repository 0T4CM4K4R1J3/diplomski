package com.touristagency.TouristAgency.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.touristagency.TouristAgency.dto.AranzmanDTO;
import com.touristagency.TouristAgency.dto.DetaljanAranzmanDTO;
import com.touristagency.TouristAgency.model.Aranzman;
import com.touristagency.TouristAgency.repository.AranzmanRepository;
import com.touristagency.TouristAgency.repository.SmestajOpisRepository;
import com.touristagency.TouristAgency.repository.TerminiRepository;

@Service
public class AranzmanService {

	@Autowired
	AranzmanRepository aranzmanRepository;
	@Autowired
	SmestajOpisService smestajOpisService;
	@Autowired
	SmestajOpisRepository smestajOpisRepository;
	@Autowired
	TerminiService terminService;
	@Autowired
	TerminiRepository terminRepository;
	
	public AranzmanDTO createAranzman(AranzmanDTO aranzmanDTO) {
		Aranzman aranzman = new Aranzman(aranzmanDTO);
		aranzman.setSmestajOpis(this.smestajOpisRepository.getReferenceById(aranzmanDTO.getSmestajOpisId()));
		aranzman.setTermin(terminRepository.getReferenceById(aranzmanDTO.getTerminId()));
		aranzmanRepository.save(aranzman);
		return new AranzmanDTO(aranzman);
	}
	
	public List<DetaljanAranzmanDTO> getAllAranzman(){
		List<Aranzman> aranzmani = aranzmanRepository.findAll(); 
		List<DetaljanAranzmanDTO> aranzmaniDTO = new ArrayList<>();
		for(Aranzman aranzman : aranzmani) {
			aranzmaniDTO.add(new DetaljanAranzmanDTO(aranzman));
		}
		return aranzmaniDTO; 
	}

	public AranzmanDTO getAranzman(Long id) {
		return new AranzmanDTO(aranzmanRepository.getReferenceById(id));
	}

	public AranzmanDTO updateAranzman(AranzmanDTO aranzmanDTO) {
		Aranzman aranzman = this.aranzmanRepository.getReferenceById(aranzmanDTO.getId());
		aranzman.setSmestajOpis(this.smestajOpisRepository.getReferenceById(aranzmanDTO.getSmestajOpisId()));
		aranzman.setTermin(this.terminRepository.getReferenceById(aranzmanDTO.getTerminId()));
		aranzman.setBrojKreveta(aranzmanDTO.getBrojKreveta());
		aranzman.setCenaZaDete(aranzmanDTO.getCenaZaDete());
		aranzman.setCenaZaOdrasluOsobu(aranzmanDTO.getCenaZaOdrasluOsobu());
		return new AranzmanDTO(aranzmanRepository.save(aranzman));
	}

	public void deleteAranzman(Long id) {
		aranzmanRepository.deleteById(id);
	}
}
