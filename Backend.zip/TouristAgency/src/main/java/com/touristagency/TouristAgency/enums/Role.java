package com.touristagency.TouristAgency.enums;

public enum Role {
	Admin, User
}
