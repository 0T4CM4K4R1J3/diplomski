package com.touristagency.TouristAgency.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.touristagency.TouristAgency.dto.DrzavaDTO;
import com.touristagency.TouristAgency.model.Drzava;
import com.touristagency.TouristAgency.repository.DrzavaRepository;

@Service
public class DrzavaService {

	@Autowired
	DrzavaRepository drzavaRepository;
	
	public DrzavaDTO createDrzava(DrzavaDTO drzavaDTO) {
		Drzava drzava = new Drzava(drzavaDTO);
		drzavaRepository.save(drzava);
		return new DrzavaDTO(drzava);
	}

	public List<DrzavaDTO> getAllDrzava(){
		List<Drzava> drzave = drzavaRepository.findAll(); 
		List<DrzavaDTO> drzaveDTO = new ArrayList<>();
		for(Drzava drzava : drzave) {
			drzaveDTO.add(new DrzavaDTO(drzava));
		}
		return drzaveDTO; 
	}

	public DrzavaDTO getDrzava(Long id) {
		return new DrzavaDTO(drzavaRepository.getReferenceById(id));
	}

	public DrzavaDTO updateDrzava(DrzavaDTO drzavaDTO) {
		Drzava drzava = drzavaRepository.getReferenceById(drzavaDTO.getId());
		drzava.setNaziv(drzavaDTO.getNaziv());
		return new DrzavaDTO(drzavaRepository.save(drzava));
	}

	public void deleteDrzava(Long id) {
		drzavaRepository.deleteById(id);
	}
}
