package com.touristagency.TouristAgency.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.touristagency.TouristAgency.dto.TerminDTO;
import com.touristagency.TouristAgency.model.Termin;
import com.touristagency.TouristAgency.repository.TerminiRepository;

@Service
public class TerminiService {

	@Autowired
	TerminiRepository terminRepository;
	
	public TerminDTO createTermin(TerminDTO terminDTO) {
		Termin termin = new Termin(terminDTO);
		terminRepository.save(termin);
		return new TerminDTO(termin);
	}

	public List<TerminDTO> getAllTermin(){
		List<Termin> termini = terminRepository.findAll(); 
		List<TerminDTO> terminiDTO = new ArrayList<>();
		for(Termin t : termini) {
			terminiDTO.add(new TerminDTO(t));
		}
		return terminiDTO; 
	}

	public TerminDTO getTermin(Long id) {
		return new TerminDTO(terminRepository.getReferenceById(id));
	}

	public TerminDTO updateTermin(TerminDTO terminDTO) {
		Termin termin = terminRepository.getReferenceById(terminDTO.getId());
		termin.setPolazak(terminDTO.getPolazak());
		termin.setPovratak(terminDTO.getPovratak());
		return new TerminDTO(terminRepository.save(termin));
	}

	public void deleteTermin(Long id) {
		terminRepository.deleteById(id);
	}
}
