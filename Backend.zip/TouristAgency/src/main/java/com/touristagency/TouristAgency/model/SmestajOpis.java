package com.touristagency.TouristAgency.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.touristagency.TouristAgency.dto.SmestajOpisDTO;

@Entity
public class SmestajOpis {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private Long id;	
	private String adresa;	
	private String slika;	
	private int zvezdica;	
	private int plaza;	
	private boolean internet;	
	private String opis;	
	
	@OneToMany(fetch=FetchType.LAZY, cascade=CascadeType.ALL, mappedBy="smestajOpis")
	private List<Aranzman> aranzmani = new ArrayList<>();
	
	@ManyToOne(fetch=FetchType.LAZY, cascade=CascadeType.PERSIST)
	private Destinacija destinacija;
	
	public SmestajOpis() {}
	
	public SmestajOpis(SmestajOpisDTO a) {
		this.adresa = a.getAdresa();
		this.slika = a.getSlika();
		this.zvezdica = a.getZvezdica();
		this.plaza = a.getPlaza();
		this.internet = a.isInternet(); 
		this.opis = a.getOpis();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAdresa() {
		return adresa;
	}

	public void setAdresa(String adresa) {
		this.adresa = adresa;
	}

	public String getSlika() {
		return slika;
	}

	public void setSlika(String slika) {
		this.slika = slika;
	}

	public int getZvezdica() {
		return zvezdica;
	}

	public void setZvezdica(int zvezdica) {
		this.zvezdica = zvezdica;
	}

	public int getPlaza() {
		return plaza;
	}

	public void setPlaza(int plaza) {
		this.plaza = plaza;
	}

	public boolean isInternet() {
		return internet;
	}

	public void setInternet(boolean internet) {
		this.internet = internet;
	}

	public String getOpis() {
		return opis;
	}

	public void setOpis(String opis) {
		this.opis = opis;
	}

	public List<Aranzman> getAranzmani() {
		return aranzmani;
	}

	public void setAranzmani(List<Aranzman> aranzmani) {
		this.aranzmani = aranzmani;
	}

	public Destinacija getDestinacija() {
		return destinacija;
	}

	public void setDestinacija(Destinacija destinacija) {
		this.destinacija = destinacija;
	}
	
}
