package com.touristagency.TouristAgency.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.touristagency.TouristAgency.dto.SmestajOpisDTO;
import com.touristagency.TouristAgency.model.SmestajOpis;
import com.touristagency.TouristAgency.repository.DestinacijaRepository;
import com.touristagency.TouristAgency.repository.SmestajOpisRepository;

@Service
public class SmestajOpisService {

	@Autowired
	SmestajOpisRepository smestajOpisRepository;
	@Autowired
	DestinacijaService destinacijaService;
	@Autowired
	DestinacijaRepository destinacijaRepository;
	
	public SmestajOpisDTO createSmestajOpis(SmestajOpisDTO smestajOpisDTO) {
		SmestajOpis smestajOpis = new SmestajOpis(smestajOpisDTO);
		smestajOpis.setDestinacija(this.destinacijaRepository.getReferenceById(smestajOpisDTO.getDestinacijaId()));
		smestajOpisRepository.save(smestajOpis);
		return new SmestajOpisDTO(smestajOpis);
	}
	
	public List<SmestajOpisDTO> getAllSmestajOpis(){
		List<SmestajOpis> smestajOpisi = smestajOpisRepository.findAll(); 
		List<SmestajOpisDTO> smestajOpisiDTO = new ArrayList<>();
		for(SmestajOpis so : smestajOpisi) {
			smestajOpisiDTO.add(new SmestajOpisDTO(so));
		}
		return smestajOpisiDTO; 
	}

	public SmestajOpisDTO getSmestajOpis(Long id) {
		return new SmestajOpisDTO(smestajOpisRepository.getReferenceById(id));
	}

	public SmestajOpisDTO updateSmestajOpis(SmestajOpisDTO smestajOpisDTO) {
		SmestajOpis smestajOpis = this.smestajOpisRepository.getReferenceById(smestajOpisDTO.getId());
		smestajOpis.setAdresa(smestajOpisDTO.getAdresa());
		smestajOpis.setSlika(smestajOpisDTO.getSlika());
		smestajOpis.setZvezdica(smestajOpisDTO.getZvezdica());
		smestajOpis.setPlaza(smestajOpisDTO.getPlaza());
		smestajOpis.setInternet(smestajOpisDTO.isInternet());
		smestajOpis.setOpis(smestajOpisDTO.getOpis());
		smestajOpis.setDestinacija(this.destinacijaRepository.getReferenceById(smestajOpisDTO.getDestinacijaId()));
		return new SmestajOpisDTO(smestajOpisRepository.save(smestajOpis));
	}

	public void deleteSmestajOpis(Long id) {
		smestajOpisRepository.deleteById(id);
	}

}
