package com.touristagency.TouristAgency.dto;

import com.touristagency.TouristAgency.model.Prevoz;

public class PrevozDTO {

	private Long id;
	private String naziv;
	
	public PrevozDTO() {}

	public PrevozDTO(Prevoz prevoz) {
		this.id = prevoz.getId();
		this.naziv = prevoz.getNaziv();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}
	
	
	
}
